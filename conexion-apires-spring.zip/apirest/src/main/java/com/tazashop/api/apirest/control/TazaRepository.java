package com.tazashop.api.apirest.control;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.tazashop.api.apirest.modelo.Almacen;

/*
 * eata clase assedera ala base de datos y a al crud en cuestion.
 */

@Repository
public interface TazaRepository extends JpaRepository<Almacen, Integer> {
	
}
