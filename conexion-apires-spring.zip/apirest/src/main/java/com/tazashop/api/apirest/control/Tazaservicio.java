package com.tazashop.api.apirest.control;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tazashop.api.apirest.modelo.Almacen;

/*
 * creacion del metodo dentro de la clase en la cual se guardaran
 * los datos dentro de la base de datos
 */
@Service
public class Tazaservicio {
	
	@Autowired
	private TazaRepository tazaRepository;
	
	public void guardar(Almacen almacen) {
		tazaRepository.save(almacen);
	}
	
	/*
	 * obtener los datos de la base de taos a asia la api 
	 * y mostrarla en la pagina en forma de lista
	 */
	public List<Almacen> obtenerTazastodas() {
		return tazaRepository.findAll();
	}
	
	/*
	 * en este metodo se obtrendran los datos dentro de la base de datosos
	 */
	public Almacen obtenerAlmacen(Integer Id) {
		return tazaRepository.getOne(Id);
	}
	
	/*
	 * en este metodo se actualizara el dato de la base de datos
	 */
	public void actualizar(Almacen almacen) {
		tazaRepository.save(almacen);
	}
	
	/*
	 * metodo de eleminacion de un dato de la base de datos
	 */
	public void Eliminar(Integer id) {
		tazaRepository.deleteById(id);
	}
	
}
