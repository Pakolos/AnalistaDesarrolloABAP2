package com.tazashop.api.apirest.modelo;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.GenerationType;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/* 
 creando los atruibutos que seran agregras a la base de datos directamente
 y lo mapea como una tabla y como coumnas.
 */
@Entity
@Table(name = "almacen")
/*
 * en el @json es para que no tenga poblemas para el objeto java no ignore al json y se
 * muestre el dato de la base de datos
 */
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class Almacen {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer Id;
	private String Taza;
	private String Color;
	private Double Capacidad;
	private String Modelo;
	private String Materia;
	
	public Almacen(){	
	}

	public Integer getId() {
		return Id;
	}

	public void setId(Integer id) {
		Id = id;
	}

	public String getTaza() {
		return Taza;
	}

	public void setTaza(String taza) {
		Taza = taza;
	}

	public String getColor() {
		return Color;
	}

	public void setColor(String color) {
		Color = color;
	}

	public Double getCapacidad() {
		return Capacidad;
	}

	public void setCapacidad(Double capacidad) {
		Capacidad = capacidad;
	}

	public String getModelo() {
		return Modelo;
	}

	public void setModelo(String modelo) {
		Modelo = modelo;
	}

	public String getMateria() {
		return Materia;
	}

	public void setMateria(String materia) {
		Materia = materia;
	}

	/*
	 es el para las partes del objeto y se utiliza para que despliege los atributos
	 */
	@Override
	public String toString() {
		return "Almacen [Id=" + Id + ", Taza=" + Taza + ", Color=" + Color + ", Capacidad=" + Capacidad + ", Modelo="
				+ Modelo + ", Materia=" + Materia + "]";
	}
	
}
