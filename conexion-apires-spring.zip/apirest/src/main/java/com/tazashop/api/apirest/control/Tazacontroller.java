package com.tazashop.api.apirest.control;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.tazashop.api.apirest.modelo.Almacen;

/*
 * se pmapea para controlar la lista de estudiantes con el metodo GET.
 */
@RestController
@CrossOrigin(origins = "http://localhost:4200/")
public class Tazacontroller {
	
	@Autowired
	private Tazaservicio almacenservicio;
	
	/*
	  en esta parte se obtiene las tazas que seran registrada en la base de datos
	 */
	@GetMapping("api/Almacen")
	public List<Almacen> obtenerAlmacen(){
		List<Almacen> listaAlmacen= new ArrayList<>();
		
		/*
		*en esta parte se agregaran los datos dde llas tazas 
		*/
		Almacen e = new Almacen();
		e.setId(1);
		e.setTaza("Taza de Ceramica");
		e.setColor("Roja");
		e.setCapacidad(250d);
		e.setModelo("05");
		e.setMateria("Ceramica");
		
		Almacen e1 = new Almacen();
		e1.setId(2);
		e1.setTaza("Taza de bloques de lego");
		e1.setColor("Azul");
		e1.setCapacidad(500d);
		e1.setModelo("21");
		e1.setMateria("Plastico");
		
		Almacen e2 = new Almacen();
		e2.setId(3);
		e2.setTaza("Taza medieval");
		e2.setColor("Negra");
		e2.setCapacidad(567d);
		e2.setModelo("09");
		e2.setMateria("Metal");
		
		Almacen e3 = new Almacen();
		e3.setId(4);
		e3.setTaza("Taza Hallowen");
		e3.setColor("Naranja");
		e3.setCapacidad(400d);
		e3.setModelo("12");
		e3.setMateria("Ceramica");
		
		listaAlmacen.add(e);
		listaAlmacen.add(e1);
		listaAlmacen.add(e2);
		listaAlmacen.add(e3);
		
		return listaAlmacen;
	}
	
	/*
	 * para guardar los datos dentro de la base de datos
	 */
	@PostMapping("api/Almacenes")
	public Almacen guardarAlmacen(@RequestBody Almacen almacen) {
		System.out.println(almacen);
		almacenservicio.guardar(almacen);
		return almacen;
	}
	
	/*
	 * implementacion del recurso para la obtencion del almacen
	 * y se obtendra como lista
	 */
	@GetMapping("api/Almacenes")
	public List<Almacen> obtener(){
		return almacenservicio.obtenerTazastodas();
	}
	
	/*
	 * se mostrara un dato de la base de datos con el id
	 */
	@GetMapping("api/Almacenes/{id}")
	public Almacen onteneruno(@PathVariable("id")Integer id) {
		return almacenservicio.obtenerAlmacen(id);	
	}
	
	/*
	 * el metodo para la actulizacion del dato de la base de datos y verse en la pagina
	 */
	@PutMapping("api/Almacenes")
	public void actualizarAlmacen(@RequestBody Almacen taza) {
		almacenservicio.actualizar(taza);
	}
	
	/*
	 * se muestra de como se elimina un dato de la base de datos 
	 */
	@DeleteMapping("api/Almacenes/{id}")
	public void eliminar(@PathVariable("id") Integer id) {
		almacenservicio.Eliminar(id);
	}
}

	
